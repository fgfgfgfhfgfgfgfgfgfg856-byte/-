@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ==============================================
echo      AlienStageTelegram - Windows builder
echo ==============================================
echo.
where node >nul 2>nul
if errorlevel 1 goto no_node
where npm >nul 2>nul
if errorlevel 1 goto no_npm

if not exist node_modules (
  echo Устанавливаю зависимости...
  call npm install
  if errorlevel 1 goto failed
)

echo Проверяю JavaScript...
call npm run check
if errorlevel 1 goto failed

echo Собираю Windows EXE установщик и portable-версию...
call npm run desktop:dist
if errorlevel 1 goto failed

echo.
echo Готовые файлы смотри в папке dist.
pause
exit /b 0

:no_node
echo Node.js не найден. Установи Node.js 22 или новее: https://nodejs.org/en/download/
goto fail_pause
:no_npm
echo npm не найден. Переустанови Node.js с опцией PATH.
goto fail_pause
:failed
echo Сборка завершилась ошибкой. Смотри сообщение выше.
:fail_pause
pause
exit /b 1
