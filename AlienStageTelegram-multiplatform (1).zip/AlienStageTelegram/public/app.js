(() => {
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const state = {
    authMode: 'login', user: null, conversations: [], contacts: [], people: [],
    activeId: null, activeConversation: null, activeMembers: [], online: new Set(), socket: null,
    peopleTimer: null, toastTimer: null, selectedGroupContacts: new Set()
  };

  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
  const initials = name => String(name || '?').trim().split(/\s+/).slice(0, 2).map(part => part[0] || '').join('').toUpperCase() || '?';
  const dateTime = value => {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    const now = new Date();
    return date.toDateString() === now.toDateString()
      ? new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit' }).format(date)
      : new Intl.DateTimeFormat('ru-RU', { day: '2-digit', month: 'short' }).format(date);
  };
  const avatar = (person, size = '') => {
    const image = person?.avatar_url
      ? `<img src="${esc(person.avatar_url)}" alt="">`
      : esc(initials(person?.display_name || person?.name || person?.username));
    return `<span class="avatar ${size}">${image}</span>`;
  };

  async function api(url, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (options.body && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
    const contentType = response.headers.get('content-type') || '';
    const data = contentType.includes('application/json') ? await response.json() : {};
    if (!response.ok) throw new Error(data.error || 'Не удалось выполнить запрос.');
    return data;
  }

  function toast(message) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => node.classList.remove('show'), 2700);
  }

  function showAuthError(message = '') { $('#auth-error').textContent = message; }
  function setAuthMode(mode) {
    state.authMode = mode;
    const registering = mode === 'register';
    $('#login-tab').classList.toggle('active', !registering);
    $('#register-tab').classList.toggle('active', registering);
    $('#name-field').classList.toggle('hidden', !registering);
    $('#auth-name').required = registering;
    $('#auth-password').autocomplete = registering ? 'new-password' : 'current-password';
    $('#auth-submit').innerHTML = registering ? 'Создать аккаунт <span>↗</span>' : 'Войти в аккаунт <span>↗</span>';
    showAuthError('');
  }

  async function submitAuth(event) {
    event.preventDefault();
    const username = $('#auth-username').value.trim().toLowerCase();
    const password = $('#auth-password').value;
    const body = { username, password };
    if (state.authMode === 'register') body.display_name = $('#auth-name').value.trim();
    const button = $('#auth-submit');
    button.disabled = true;
    button.textContent = state.authMode === 'register' ? 'Создаём аккаунт…' : 'Входим…';
    showAuthError('');
    try {
      const result = await api(`/api/auth/${state.authMode === 'register' ? 'register' : 'login'}`, {
        method: 'POST', body: JSON.stringify(body)
      });
      state.user = result.user;
      await startApp();
    } catch (error) {
      showAuthError(error.message);
      setAuthMode(state.authMode);
    } finally {
      button.disabled = false;
    }
  }

  async function boot() {
    try {
      const result = await api('/api/me');
      state.user = result.user;
      await startApp();
    } catch {
      $('#auth-screen').classList.remove('hidden');
      $('#app').classList.add('hidden');
    }
  }

  async function startApp() {
    $('#auth-screen').classList.add('hidden');
    $('#app').classList.remove('hidden');
    renderProfileBits();
    connectSocket();
    await loadConversations();
    switchView('messages');
    if (state.conversations.length) await openConversation(state.conversations[0].id);
  }

  function connectSocket() {
    if (state.socket) state.socket.disconnect();
    if (typeof window.io !== 'function') {
      toast('Не удалось подключиться к онлайн-связи. Обнови страницу.');
      return;
    }
    state.socket = window.io({ transports: ['websocket', 'polling'] });
    state.socket.on('connect_error', () => toast('Нет соединения с сервером. Проверь интернет.'));
    state.socket.on('presence:snapshot', ids => {
      state.online = new Set(ids || []);
      renderConversationList();
      renderPeople();
    });
    state.socket.on('presence:update', event => {
      if (event?.user_id) {
        if (event.online) state.online.add(event.user_id);
        else state.online.delete(event.user_id);
        renderConversationList();
        renderPeople();
      }
    });
    state.socket.on('inbox:changed', () => loadConversations());
    state.socket.on('message:new', message => {
      const conversation = state.conversations.find(item => item.id === message.conversation_id);
      if (conversation) {
        conversation.last_message = message.body;
        conversation.last_message_at = message.created_at;
        conversation.has_messages = true;
      }
      renderConversationList();
      if (message.conversation_id === state.activeId) appendMessage(message);
    });
  }

  async function loadConversations() {
    try {
      const data = await api('/api/conversations');
      state.conversations = data.conversations || [];
      if (state.socket?.connected) state.conversations.forEach(item => state.socket.emit('conversation:subscribe', item.id));
      renderConversationList();
    } catch (error) { toast(error.message); }
  }

  function renderProfileBits() {
    if (!state.user) return;
    $('#my-display-name').textContent = state.user.display_name;
    $('#my-username').textContent = `@${state.user.username}`;
    $('#my-avatar').innerHTML = state.user.avatar_url ? `<img src="${esc(state.user.avatar_url)}" alt="">` : esc(initials(state.user.display_name));
  }

  function switchView(view) {
    const peopleView = view === 'people';
    $('#nav-people').classList.toggle('active', peopleView);
    $('#nav-messages').classList.toggle('active', !peopleView);
    $('#list-eyebrow').textContent = peopleView ? 'FIND YOUR PEOPLE' : 'YOUR SPACE';
    $('#list-title').textContent = peopleView ? 'Люди' : 'Сообщения';
    $('#search-input').value = '';
    $('#search-input').placeholder = peopleView ? 'Найти людей по нику' : 'Поиск чатов';
    $('#people-hint').classList.toggle('hidden', !peopleView);
    $('#create-group-open').classList.toggle('hidden', peopleView);
    $('#conversation-list').dataset.view = view;
    if (peopleView) {
      state.people = [];
      renderPeople();
      $('#search-input').focus();
    } else renderConversationList();
  }

  function renderConversationList() {
    if ($('#conversation-list').dataset.view === 'people') return;
    const query = $('#search-input').value.trim().toLowerCase();
    const chats = state.conversations.filter(item => {
      const person = item.peer;
      return !query || [item.name, person?.username, item.last_message].some(value => String(value || '').toLowerCase().includes(query));
    });
    if (!chats.length) {
      $('#conversation-list').innerHTML = `<div class="empty-list">${query ? 'Ничего не найдено.' : 'Пока нет чатов.<br>Открой раздел «Люди», найди собеседника и напиши ему.'}</div>`;
      return;
    }
    $('#conversation-list').innerHTML = chats.map(item => {
      const person = item.peer;
      const online = person && state.online.has(person.id);
      const badge = person ? (online ? '●' : '') : '✦';
      const preview = item.last_message ? esc(item.last_message) : 'Начни общение';
      return `<button type="button" class="conversation-item ${state.activeId === item.id ? 'active' : ''}" data-conversation="${esc(item.id)}">
        ${avatar(item.peer || { name: item.name, display_name: item.name, avatar_url: item.avatar_url })}
        <span class="conversation-copy"><span class="conversation-line"><span class="conversation-name">${esc(item.name)}</span><span class="conversation-time">${esc(dateTime(item.last_message_at || item.created_at))}</span></span>
        <span class="conversation-line"><span class="conversation-preview">${preview}</span><span class="conversation-time">${badge}</span></span></span>
      </button>`;
    }).join('');
    $$('.conversation-item').forEach(button => button.addEventListener('click', () => openConversation(button.dataset.conversation)));
  }

  async function searchPeople(query) {
    if (query.trim().length < 2) {
      state.people = [];
      renderPeople();
      return;
    }
    try {
      const result = await api(`/api/users?q=${encodeURIComponent(query.trim())}`);
      // Ignore slow responses if the search box has changed meanwhile.
      if ($('#conversation-list').dataset.view !== 'people' || $('#search-input').value.trim() !== query.trim()) return;
      state.people = result.users || [];
      renderPeople();
    } catch (error) { toast(error.message); }
  }

  function renderPeople() {
    if ($('#conversation-list').dataset.view !== 'people') return;
    const query = $('#search-input').value.trim();
    if (query.length < 2) {
      $('#conversation-list').innerHTML = '<div class="empty-list">Введи минимум 2 символа, чтобы найти зарегистрированных пользователей.</div>';
      return;
    }
    if (!state.people.length) {
      $('#conversation-list').innerHTML = '<div class="empty-list">Никого не нашли. Проверь написание никнейма.</div>';
      return;
    }
    $('#conversation-list').innerHTML = state.people.map(person => {
      const online = state.online.has(person.id);
      return `<div class="person-result">${avatar(person)}<div class="person-result-copy"><div class="person-result-name">${esc(person.display_name)}</div><div class="person-result-user">@${esc(person.username)} · ${online ? '<span class="online-dot"></span> в сети' : 'пользователь AST'}</div></div><button class="person-message-btn" type="button" data-message-user="${esc(person.id)}">Написать</button></div>`;
    }).join('');
    $$('[data-message-user]').forEach(button => button.addEventListener('click', () => startDirect(button.dataset.messageUser)));
  }

  async function startDirect(userId) {
    try {
      const result = await api(`/api/direct/${encodeURIComponent(userId)}`, { method: 'POST', body: '{}' });
      switchView('messages');
      await loadConversations();
      await openConversation(result.conversation_id);
      $('#app').classList.add('show-chat');
    } catch (error) { toast(error.message); }
  }

  async function openConversation(id) {
    const item = state.conversations.find(conversation => conversation.id === id);
    if (!item) {
      await loadConversations();
    }
    const conversation = state.conversations.find(entry => entry.id === id);
    if (!conversation) return;
    state.activeId = id;
    state.activeConversation = conversation;
    state.activeMembers = [];
    $('#welcome-screen').classList.add('hidden');
    $('#chat-screen').classList.remove('hidden');
    $('#app').classList.add('show-chat');
    $('#chat-title').textContent = conversation.name;
    $('#chat-avatar').innerHTML = conversation.avatar_url ? `<img src="${esc(conversation.avatar_url)}" alt="">` : esc(initials(conversation.name));
    const online = conversation.peer && state.online.has(conversation.peer.id);
    $('#chat-subtitle').textContent = conversation.type === 'group'
      ? `${conversation.member_count} участников · групповая переписка`
      : online ? '● в сети' : `@${conversation.peer?.username || ''}`;
    renderConversationList();
    if (state.socket?.connected) state.socket.emit('conversation:subscribe', id);
    $('#messages').innerHTML = '<div class="message-empty">Загружаем историю…</div>';
    try {
      const result = await api(`/api/conversations/${encodeURIComponent(id)}/messages`);
      if (state.activeId !== id) return;
      $('#messages').innerHTML = '';
      if (!result.messages.length) {
        $('#messages').innerHTML = '<div class="message-empty"><strong>Переписка начинается здесь</strong>Отправь первое сообщение, чтобы начать разговор.</div>';
      } else result.messages.forEach(appendMessage);
      scrollMessages();
    } catch (error) { toast(error.message); }
  }

  function appendMessage(message) {
    if (!message || message.conversation_id !== state.activeId) return;
    if ($(`[data-message-id="${CSS.escape(message.id)}"]`, $('#messages'))) return;
    const empty = $('.message-empty', $('#messages'));
    if (empty) empty.remove();
    const mine = message.sender_id === state.user.id;
    const showSender = state.activeConversation?.type === 'group' && !mine;
    const row = document.createElement('div');
    row.className = `message-row ${mine ? 'mine' : ''}`;
    row.dataset.messageId = message.id;
    const person = { display_name: message.sender_name, avatar_url: message.sender_avatar };
    row.innerHTML = `${mine ? '' : avatar(person, 'message-avatar')}<div class="message-bubble">${showSender ? `<div class="message-sender">${esc(message.sender_name)}</div>` : ''}${esc(message.body)}<div class="message-meta"><span>${esc(new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit' }).format(new Date(message.created_at)))}</span>${mine ? '<span>✓</span>' : ''}</div></div>`;
    $('#messages').append(row);
    scrollMessages();
  }

  function scrollMessages() {
    const area = $('#message-area');
    area.scrollTop = area.scrollHeight;
  }

  async function sendMessage(event) {
    event.preventDefault();
    const body = $('#message-input').value.trim();
    if (!body || !state.activeId) return;
    const button = $('.send-button');
    button.disabled = true;
    try {
      await api(`/api/conversations/${encodeURIComponent(state.activeId)}/messages`, {
        method: 'POST', body: JSON.stringify({ body })
      });
      $('#message-input').value = '';
      $('#message-input').style.height = '38px';
      await loadConversations();
    } catch (error) { toast(error.message); }
    finally { button.disabled = false; $('#message-input').focus(); }
  }

  async function openProfile() {
    $('#profile-display-name').value = state.user.display_name;
    $('#profile-username').textContent = `@${state.user.username}`;
    $('#profile-avatar-preview').innerHTML = state.user.avatar_url ? `<img src="${esc(state.user.avatar_url)}" alt="">` : esc(initials(state.user.display_name));
    $('#profile-error').textContent = '';
    $('#profile-modal').classList.remove('hidden');
  }

  async function saveProfile() {
    const name = $('#profile-display-name').value.trim();
    try {
      const result = await api('/api/me', { method: 'PATCH', body: JSON.stringify({ display_name: name }) });
      state.user = result.user;
      renderProfileBits();
      $('#profile-modal').classList.add('hidden');
      toast('Профиль обновлён.');
    } catch (error) { $('#profile-error').textContent = error.message; }
  }

  async function uploadAvatar(file) {
    if (!file) return;
    const form = new FormData();
    form.append('avatar', file);
    try {
      const result = await api('/api/me/avatar', { method: 'POST', body: form });
      state.user = result.user;
      renderProfileBits();
      $('#profile-avatar-preview').innerHTML = `<img src="${esc(state.user.avatar_url)}?v=${Date.now()}" alt="">`;
      toast('Аватар изменён.');
    } catch (error) { $('#profile-error').textContent = error.message; }
    finally { $('#avatar-file').value = ''; }
  }

  async function openGroupModal() {
    $('#group-name').value = '';
    $('#group-error').textContent = '';
    state.selectedGroupContacts.clear();
    $('#group-modal').classList.remove('hidden');
    await loadContacts();
    renderContactChoices('#group-contact-list', state.contacts, 'group-check');
    updateGroupCount();
  }

  async function loadContacts() {
    const result = await api('/api/contacts');
    state.contacts = result.contacts || [];
  }

  function renderContactChoices(selector, contacts, className, excluded = new Set()) {
    const available = contacts.filter(person => !excluded.has(person.id));
    if (!available.length) {
      $(selector).innerHTML = '<div class="empty-list">Пока нет подходящих собеседников. Сначала начни личную переписку.</div>';
      return;
    }
    $(selector).innerHTML = available.map(person => `<label class="select-option">${avatar(person)}<span class="select-copy"><strong>${esc(person.display_name)}</strong><small>@${esc(person.username)}</small></span><input class="${className}" type="checkbox" value="${esc(person.id)}"></label>`).join('');
    $$(`.${className}`).forEach(input => input.addEventListener('change', () => {
      if (className === 'group-check') {
        if (input.checked) state.selectedGroupContacts.add(input.value);
        else state.selectedGroupContacts.delete(input.value);
        updateGroupCount();
      }
    }));
  }

  function updateGroupCount() { $('#group-selected-count').textContent = `${state.selectedGroupContacts.size} выбрано`; }

  async function createGroup() {
    const name = $('#group-name').value.trim();
    const memberIds = [...state.selectedGroupContacts];
    try {
      const result = await api('/api/groups', { method: 'POST', body: JSON.stringify({ name, member_ids: memberIds }) });
      $('#group-modal').classList.add('hidden');
      await loadConversations();
      await openConversation(result.conversation_id);
      toast('Группа создана.');
    } catch (error) { $('#group-error').textContent = error.message; }
  }

  async function openInfo() {
    if (!state.activeId) return;
    try {
      const data = await api(`/api/conversations/${encodeURIComponent(state.activeId)}`);
      state.activeMembers = data.members || [];
      const group = data.conversation.type === 'group';
      $('#info-title').textContent = group ? data.conversation.name : 'Личная переписка';
      $('#info-summary').innerHTML = group
        ? `Группа создана участником. Всего участников: <b>${state.activeMembers.length}</b>.`
        : 'Личный чат между двумя зарегистрированными пользователями.';
      $('#invite-open').classList.toggle('hidden', !group);
      $('#info-members').innerHTML = state.activeMembers.map(member => `<div class="member-row">${avatar(member)}<span class="member-copy"><strong>${esc(member.display_name)}</strong><small>@${esc(member.username)}</small></span>${member.id === data.conversation.created_by ? '<span class="owner-tag">СОЗДАТЕЛЬ</span>' : ''}</div>`).join('');
      $('#info-modal').classList.remove('hidden');
    } catch (error) { toast(error.message); }
  }

  async function openInviteModal() {
    $('#invite-error').textContent = '';
    $('#invite-modal').classList.remove('hidden');
    try {
      await loadContacts();
      const existing = new Set(state.activeMembers.map(member => member.id));
      renderContactChoices('#invite-contact-list', state.contacts, 'invite-check', existing);
    } catch (error) { $('#invite-error').textContent = error.message; }
  }

  async function inviteSelected() {
    const selected = $('.invite-check:checked', $('#invite-contact-list'));
    if (!selected) { $('#invite-error').textContent = 'Выбери собеседника для приглашения.'; return; }
    try {
      await api(`/api/groups/${encodeURIComponent(state.activeId)}/invite`, { method: 'POST', body: JSON.stringify({ user_id: selected.value }) });
      $('#invite-modal').classList.add('hidden');
      $('#info-modal').classList.add('hidden');
      await loadConversations();
      await openInfo();
      toast('Участник добавлен в группу.');
    } catch (error) { $('#invite-error').textContent = error.message; }
  }

  async function logout() {
    try { await api('/api/auth/logout', { method: 'POST', body: '{}' }); } catch { /* local UI is still cleared */ }
    if (state.socket) state.socket.disconnect();
    state.user = null;
    state.conversations = [];
    state.activeId = null;
    $('#app').classList.add('hidden');
    $('#app').classList.remove('show-chat');
    $('#auth-screen').classList.remove('hidden');
    $('#auth-form').reset();
    setAuthMode('login');
  }

  // Authentication
  $('#login-tab').addEventListener('click', () => setAuthMode('login'));
  $('#register-tab').addEventListener('click', () => setAuthMode('register'));
  $('#auth-form').addEventListener('submit', submitAuth);

  // Navigation and search
  $('#nav-messages').addEventListener('click', () => switchView('messages'));
  $('#nav-people').addEventListener('click', () => switchView('people'));
  $('#search-input').addEventListener('input', () => {
    if ($('#conversation-list').dataset.view === 'people') {
      clearTimeout(state.peopleTimer);
      state.peopleTimer = setTimeout(() => searchPeople($('#search-input').value), 220);
    } else renderConversationList();
  });
  document.addEventListener('keydown', event => {
    if (event.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) && $('#auth-screen').classList.contains('hidden')) {
      event.preventDefault(); $('#search-input').focus();
    }
    if (event.key === 'Escape') $$('.modal-backdrop').forEach(modal => modal.classList.add('hidden'));
  });

  // Chat actions
  $('#message-form').addEventListener('submit', sendMessage);
  $('#message-input').addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); $('#message-form').requestSubmit(); }
  });
  $('#message-input').addEventListener('input', event => {
    event.target.style.height = '38px';
    event.target.style.height = `${Math.min(event.target.scrollHeight, 130)}px`;
  });
  $('#chat-info-open').addEventListener('click', openInfo);
  $('#mobile-back').addEventListener('click', () => $('#app').classList.remove('show-chat'));

  // Profile
  $('#profile-open').addEventListener('click', openProfile);
  $('#profile-save').addEventListener('click', saveProfile);
  $('#avatar-file').addEventListener('change', event => uploadAvatar(event.target.files?.[0]));
  $('#logout-btn').addEventListener('click', logout);

  // Groups
  $('#create-group-open').addEventListener('click', openGroupModal);
  $('#group-create').addEventListener('click', createGroup);
  $('#invite-open').addEventListener('click', openInviteModal);
  $('#invite-confirm').addEventListener('click', inviteSelected);
  $$('[data-close]').forEach(button => button.addEventListener('click', () => $(`#${button.dataset.close}`).classList.add('hidden')));
  $$('.modal-backdrop').forEach(backdrop => backdrop.addEventListener('click', event => {
    if (event.target === backdrop) backdrop.classList.add('hidden');
  }));

  boot();
})();
