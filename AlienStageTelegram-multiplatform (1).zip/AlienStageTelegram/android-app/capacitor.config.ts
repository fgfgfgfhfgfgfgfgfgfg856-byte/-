import type { CapacitorConfig } from '@capacitor/cli';

const env = (globalThis as unknown as { process?: { env?: Record<string, string | undefined> } }).process?.env ?? {};
const serverUrl = (env.AST_SERVER_URL || '').trim();

const config: CapacitorConfig = {
  appId: 'com.alienstage.telegram',
  appName: 'AlienStageTelegram',
  webDir: 'www',
  android: {
    allowMixedContent: false
  },
  ...(serverUrl ? {
    server: {
      url: serverUrl,
      cleartext: false
    }
  } : {})
};

export default config;
