@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ==============================================
echo      AlienStageTelegram - Android builder
echo ==============================================
echo.
echo Введи HTTPS-адрес опубликованного сервера.
echo Пример: https://chat.example.com
echo Без опубликованного сервера APK не сможет
echo общаться с другими пользователями.
echo.
set /p AST_SERVER_URL=Адрес сервера: 
if "%AST_SERVER_URL%"=="" goto no_url
if /i not "%AST_SERVER_URL:~0,8%"=="https://" goto bad_url

where node >nul 2>nul
if errorlevel 1 goto no_node
where npm >nul 2>nul
if errorlevel 1 goto no_npm

if not exist node_modules (
  echo Устанавливаю Android-зависимости...
  call npm install
  if errorlevel 1 goto failed
)

if not exist android (
  echo Создаю Android-проект...
  call npx cap add android
  if errorlevel 1 goto failed
)

echo Синхронизирую приложение...
call npx cap sync android
if errorlevel 1 goto failed

echo Открываю проект в Android Studio...
call npx cap open android
if errorlevel 1 goto failed

echo.
echo В Android Studio выбери Build - Generate App Bundles or APKs - Build APKs.
echo Готовый APK появится в android\app\build\outputs\apk\debug\
pause
exit /b 0

:no_url
echo Адрес сервера обязателен.
goto fail_pause
:bad_url
echo Нужен адрес с https://. Обычный http для интернет-сервера небезопасен.
goto fail_pause
:no_node
echo Node.js не найден. Установи Node.js 22 или новее: https://nodejs.org/en/download/
goto fail_pause
:no_npm
echo npm не найден. Переустанови Node.js с опцией PATH.
goto fail_pause
:failed
echo Сборка или синхронизация завершилась ошибкой. Смотри сообщение выше.
:fail_pause
pause
exit /b 1
