'use strict';

const { app, BrowserWindow, shell, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');

app.setName('AlienStageTelegram');
app.setAppUserModelId('com.alienstage.telegram');

let localBackend = null;
let mainWindow = null;
let isQuitting = false;
let cachedAppUrl = null;

function readSettings() {
  const file = path.join(app.getPath('userData'), 'config.json');
  try {
    const value = JSON.parse(fs.readFileSync(file, 'utf8'));
    return { serverUrl: typeof value.serverUrl === 'string' ? value.serverUrl.trim() : '' };
  } catch {
    return { serverUrl: '' };
  }
}

function ensureLocalData() {
  const base = path.join(app.getPath('userData'), 'data');
  const uploads = path.join(app.getPath('userData'), 'uploads');
  fs.mkdirSync(base, { recursive: true });
  fs.mkdirSync(uploads, { recursive: true });
  process.env.AST_DATA_DIR = base;
  process.env.AST_UPLOAD_DIR = uploads;
  const secretFile = path.join(app.getPath('userData'), 'jwt-secret');
  if (!fs.existsSync(secretFile)) fs.writeFileSync(secretFile, crypto.randomBytes(48).toString('hex'), { mode: 0o600 });
  process.env.JWT_SECRET ||= fs.readFileSync(secretFile, 'utf8').trim();
}

async function resolveAppUrl() {
  if (cachedAppUrl) return cachedAppUrl;
  const settings = readSettings();
  if (settings.serverUrl) {
    try {
      const parsed = new URL(settings.serverUrl);
      if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error('Unsupported protocol');
      if (parsed.protocol === 'http:' && parsed.hostname !== 'localhost' && parsed.hostname !== '127.0.0.1') {
        throw new Error('Remote server must use HTTPS');
      }
      cachedAppUrl = settings.serverUrl.replace(/\/$/, '');
      return cachedAppUrl;
    } catch (error) {
      await dialog.showMessageBox({
        type: 'warning',
        title: 'Адрес сервера не распознан',
        message: 'В config.json указан неправильный адрес сервера.',
        detail: 'Исправь serverUrl. Для сервера в интернете используй адрес, начинающийся с https://.'
      });
    }
  }

  ensureLocalData();
  const { startServer } = require('./server.js');
  const result = await startServer(0, '127.0.0.1');
  localBackend = result.server;
  cachedAppUrl = result.url;
  return cachedAppUrl;
}

async function createWindow() {
  const url = await resolveAppUrl();
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 760,
    minHeight: 560,
    title: 'AlienStageTelegram',
    backgroundColor: '#100e1b',
    show: false,
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({ url: target }) => {
    try {
      const targetUrl = new URL(target);
      if (targetUrl.protocol === 'https:' || targetUrl.protocol === 'http:') shell.openExternal(target);
    } catch { /* Ignore malformed external URLs. */ }
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, target) => {
    if (target !== url && !target.startsWith(`${url}/`)) {
      event.preventDefault();
      try { shell.openExternal(target); } catch { /* Ignore invalid targets. */ }
    }
  });
  await mainWindow.loadURL(url);
  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(createWindow).catch(async error => {
  console.error(error);
  await dialog.showMessageBox({
    type: 'error',
    title: 'AlienStageTelegram не запустился',
    message: 'Не удалось запустить приложение.',
    detail: String(error && error.message ? error.message : error)
  });
  app.quit();
});

app.on('before-quit', () => {
  isQuitting = true;
  if (localBackend?.listening) localBackend.close();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin' || isQuitting) app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow().catch(console.error);
});
