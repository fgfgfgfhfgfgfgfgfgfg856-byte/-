require('dotenv').config();

const express = require('express');
const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookie = require('cookie');
const multer = require('multer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { Server: SocketServer } = require('socket.io');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
// Desktop builds store writable data in the user's profile, not inside the installed app.
const DATA_DIR = process.env.AST_DATA_DIR || path.join(ROOT, 'data');
const UPLOAD_DIR = process.env.AST_UPLOAD_DIR || path.join(ROOT, 'uploads');
for (const dir of [DATA_DIR, UPLOAD_DIR]) fs.mkdirSync(dir, { recursive: true });

const isProduction = process.env.NODE_ENV === 'production';
const JWT_SECRET = process.env.JWT_SECRET || 'local-development-secret-change-before-deploying';
if (isProduction && JWT_SECRET === 'local-development-secret-change-before-deploying') {
  throw new Error('Set JWT_SECRET to a long random value before running in production.');
}

const db = new Database(path.join(DATA_DIR, 'alienstage.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_path TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL CHECK(type IN ('direct','group')),
    name TEXT,
    direct_key TEXT UNIQUE,
    created_by TEXT NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
  CREATE TABLE IF NOT EXISTS conversation_members (
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('owner','member')),
    joined_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    PRIMARY KEY(conversation_id, user_id)
  );
  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
  );
  CREATE INDEX IF NOT EXISTS idx_members_user ON conversation_members(user_id);
  CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, created_at);
`);

const app = express();
const server = http.createServer(app);
const io = new SocketServer(server, { serveClient: true, cors: { origin: false } });
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      connectSrc: ["'self'", 'ws:', 'wss:'],
      fontSrc: ["'self'", 'data:'],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use(express.static(PUBLIC_DIR, { extensions: ['html'] }));
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '1d', fallthrough: false }));

// Cookie-based auth + SameSite cookies; reject cross-origin state-changing browser requests.
app.use('/api', (req, res, next) => {
  if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method)) {
    const origin = req.get('origin');
    if (origin) {
      try {
        if (new URL(origin).host !== req.get('host')) return res.status(403).json({ error: 'Запрос отклонён.' });
      } catch { return res.status(403).json({ error: 'Некорректный источник запроса.' }); }
    }
  }
  next();
});

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Слишком много попыток. Попробуй позже.' } });
const messageLimiter = rateLimit({ windowMs: 60 * 1000, limit: 50, standardHeaders: 'draft-7', legacyHeaders: false,
  message: { error: 'Слишком много сообщений. Подожди немного.' } });

function makeToken(userId) { return jwt.sign({ sub: userId }, JWT_SECRET, { expiresIn: '30d' }); }
function setSession(res, userId) {
  res.cookie('ast_session', makeToken(userId), {
    httpOnly: true, secure: isProduction, sameSite: 'lax', path: '/', maxAge: 30 * 24 * 60 * 60 * 1000
  });
}
function publicUser(user) {
  return { id: user.id, username: user.username, display_name: user.display_name, avatar_url: user.avatar_path || null, created_at: user.created_at };
}
function auth(req, res, next) {
  try {
    const token = cookie.parse(req.headers.cookie || '').ast_session;
    if (!token) return res.status(401).json({ error: 'Сначала войди в аккаунт.' });
    const payload = jwt.verify(token, JWT_SECRET);
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(payload.sub);
    if (!user) return res.status(401).json({ error: 'Аккаунт не найден. Войди снова.' });
    req.user = user;
    next();
  } catch { return res.status(401).json({ error: 'Сессия закончилась. Войди снова.' }); }
}
function requireMember(conversationId, userId) {
  return !!db.prepare('SELECT 1 FROM conversation_members WHERE conversation_id = ? AND user_id = ?').get(conversationId, userId);
}
function directKey(a, b) { return [a, b].sort().join(':'); }
function hasDirectHistory(a, b) {
  const key = directKey(a, b);
  return !!db.prepare(`SELECT 1 FROM conversations c WHERE c.type='direct' AND c.direct_key=?
    AND EXISTS (SELECT 1 FROM messages m WHERE m.conversation_id=c.id)`).get(key);
}
function avatarMime(buffer) {
  if (buffer.length >= 8 && buffer.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'png';
  if (buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpg';
  if (buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  return null;
}
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 3 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => cb(null, ['image/png', 'image/jpeg', 'image/webp'].includes(file.mimetype)) });

app.post('/api/auth/register', authLimiter, (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const displayName = String(req.body.display_name || '').trim();
  const password = String(req.body.password || '');
  if (!/^[a-z0-9_]{3,20}$/.test(username)) return res.status(400).json({ error: 'Ник: 3–20 символов, только латинские буквы, цифры и _.' });
  if (displayName.length < 2 || displayName.length > 40) return res.status(400).json({ error: 'Имя должно быть длиной от 2 до 40 символов.' });
  if (password.length < 8 || password.length > 128) return res.status(400).json({ error: 'Пароль должен содержать от 8 до 128 символов.' });
  if (db.prepare('SELECT 1 FROM users WHERE username = ? COLLATE NOCASE').get(username)) return res.status(409).json({ error: 'Этот ник уже занят. Придумай другой.' });
  const id = crypto.randomUUID();
  const hash = bcrypt.hashSync(password, 12);
  db.prepare('INSERT INTO users (id, username, display_name, password_hash) VALUES (?, ?, ?, ?)').run(id, username, displayName, hash);
  setSession(res, id);
  res.status(201).json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(id)) });
});

app.post('/api/auth/login', authLimiter, (req, res) => {
  const username = String(req.body.username || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE username = ? COLLATE NOCASE').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Неправильный ник или пароль.' });
  setSession(res, user.id);
  res.json({ user: publicUser(user) });
});

app.post('/api/auth/logout', auth, (_req, res) => {
  res.clearCookie('ast_session', { httpOnly: true, secure: isProduction, sameSite: 'lax', path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
app.patch('/api/me', auth, (req, res) => {
  const displayName = String(req.body.display_name || '').trim();
  if (displayName.length < 2 || displayName.length > 40) return res.status(400).json({ error: 'Имя должно быть длиной от 2 до 40 символов.' });
  db.prepare('UPDATE users SET display_name=? WHERE id=?').run(displayName, req.user.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
});

app.post('/api/me/avatar', auth, upload.single('avatar'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Выбери PNG, JPG или WEBP изображение.' });
  const ext = avatarMime(req.file.buffer);
  if (!ext) return res.status(400).json({ error: 'Файл не похож на настоящее изображение PNG, JPG или WEBP.' });
  const filename = `${crypto.randomUUID()}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, filename), req.file.buffer, { flag: 'wx' });
  const old = req.user.avatar_path;
  const avatarPath = `/uploads/${filename}`;
  db.prepare('UPDATE users SET avatar_path=? WHERE id=?').run(avatarPath, req.user.id);
  if (old && old.startsWith('/uploads/')) {
    const oldPath = path.join(UPLOAD_DIR, path.basename(old));
    if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
  }
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id)) });
});

// Search returns only accounts which really exist in this server's database.
app.get('/api/users', auth, (req, res) => {
  const q = String(req.query.q || '').trim().replace(/[%_]/g, '');
  if (q.length < 2) return res.json({ users: [] });
  const term = `%${q}%`;
  const rows = db.prepare(`SELECT id, username, display_name, avatar_path, created_at FROM users
    WHERE id <> ? AND (username LIKE ? COLLATE NOCASE OR display_name LIKE ? COLLATE NOCASE)
    ORDER BY username COLLATE NOCASE LIMIT 30`).all(req.user.id, term, term);
  res.json({ users: rows.map(publicUser) });
});

// People with whom this account has exchanged at least one direct message.
app.get('/api/contacts', auth, (req, res) => {
  const rows = db.prepare(`SELECT u.id, u.username, u.display_name, u.avatar_path, u.created_at,
    MAX(m.created_at) AS last_message_at
    FROM conversations c
    JOIN conversation_members mine ON mine.conversation_id=c.id AND mine.user_id=?
    JOIN conversation_members other ON other.conversation_id=c.id AND other.user_id<>?
    JOIN users u ON u.id=other.user_id
    JOIN messages m ON m.conversation_id=c.id
    WHERE c.type='direct'
    GROUP BY u.id
    ORDER BY last_message_at DESC`).all(req.user.id, req.user.id);
  res.json({ contacts: rows.map(publicUser) });
});

app.get('/api/conversations', auth, (req, res) => {
  const rows = db.prepare(`SELECT c.id, c.type, c.name, c.created_at,
    (SELECT COUNT(*) FROM conversation_members cm WHERE cm.conversation_id=c.id) AS member_count,
    (SELECT body FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC, m.rowid DESC LIMIT 1) AS last_message,
    (SELECT created_at FROM messages m WHERE m.conversation_id=c.id ORDER BY m.created_at DESC, m.rowid DESC LIMIT 1) AS last_message_at
    FROM conversations c JOIN conversation_members mine ON mine.conversation_id=c.id
    WHERE mine.user_id=?
    ORDER BY COALESCE(last_message_at, c.created_at) DESC`).all(req.user.id);
  const result = rows.map(row => {
    if (row.type === 'group') return { ...row, avatar_url: null, peer: null, has_messages: !!row.last_message_at };
    const peerRow = db.prepare(`SELECT u.id,u.username,u.display_name,u.avatar_path FROM conversation_members cm
      JOIN users u ON u.id=cm.user_id WHERE cm.conversation_id=? AND cm.user_id<>?`).get(row.id, req.user.id);
    const peer = peerRow ? publicUser(peerRow) : null;
    return { ...row, name: peer?.display_name || 'Неизвестный пользователь', avatar_url: peer?.avatar_url || null,
      peer, has_messages: !!row.last_message_at };
  });
  res.json({ conversations: result });
});

app.post('/api/direct/:userId', auth, (req, res) => {
  const otherId = String(req.params.userId);
  if (otherId === req.user.id) return res.status(400).json({ error: 'Нельзя начать чат с самим собой.' });
  const other = db.prepare('SELECT id FROM users WHERE id=?').get(otherId);
  if (!other) return res.status(404).json({ error: 'Этот пользователь не зарегистрирован.' });
  const key = directKey(req.user.id, otherId);
  let conversation = db.prepare('SELECT * FROM conversations WHERE direct_key=?').get(key);
  if (!conversation) {
    const id = crypto.randomUUID();
    const create = db.transaction(() => {
      db.prepare("INSERT INTO conversations (id,type,direct_key,created_by) VALUES (?,'direct',?,?)").run(id, key, req.user.id);
      const add = db.prepare('INSERT INTO conversation_members (conversation_id,user_id,role) VALUES (?,?,?)');
      add.run(id, req.user.id, 'owner');
      add.run(id, otherId, 'member');
    });
    create();
    conversation = db.prepare('SELECT * FROM conversations WHERE id=?').get(id);
    io.to(`user:${otherId}`).emit('inbox:changed');
  }
  res.json({ conversation_id: conversation.id });
});

app.get('/api/conversations/:id', auth, (req, res) => {
  const conversation = db.prepare('SELECT * FROM conversations WHERE id=?').get(req.params.id);
  if (!conversation || !requireMember(conversation.id, req.user.id)) return res.status(404).json({ error: 'Чат не найден.' });
  const members = db.prepare(`SELECT u.id,u.username,u.display_name,u.avatar_path,cm.role
    FROM conversation_members cm JOIN users u ON u.id=cm.user_id
    WHERE cm.conversation_id=? ORDER BY cm.joined_at`).all(conversation.id).map(member => ({ ...publicUser(member), role: member.role }));
  res.json({ conversation: { id: conversation.id, type: conversation.type, name: conversation.name, created_by: conversation.created_by }, members });
});

app.get('/api/conversations/:id/messages', auth, (req, res) => {
  const id = req.params.id;
  if (!requireMember(id, req.user.id)) return res.status(404).json({ error: 'Чат не найден.' });
  const rows = db.prepare(`SELECT m.id,m.conversation_id,m.sender_id,m.body,m.created_at,
    u.username AS sender_username,u.display_name AS sender_name,u.avatar_path AS sender_avatar
    FROM messages m JOIN users u ON u.id=m.sender_id
    WHERE m.conversation_id=? ORDER BY m.created_at DESC,m.rowid DESC LIMIT 80`).all(id).reverse();
  res.json({ messages: rows });
});

app.post('/api/conversations/:id/messages', auth, messageLimiter, (req, res) => {
  const conversationId = req.params.id;
  if (!requireMember(conversationId, req.user.id)) return res.status(404).json({ error: 'Чат не найден.' });
  const body = String(req.body.body || '').trim();
  if (!body || body.length > 2000) return res.status(400).json({ error: 'Сообщение должно быть от 1 до 2000 символов.' });
  const id = crypto.randomUUID();
  db.prepare('INSERT INTO messages (id,conversation_id,sender_id,body) VALUES (?,?,?,?)').run(id, conversationId, req.user.id, body);
  const message = db.prepare(`SELECT m.id,m.conversation_id,m.sender_id,m.body,m.created_at,
    u.username AS sender_username,u.display_name AS sender_name,u.avatar_path AS sender_avatar
    FROM messages m JOIN users u ON u.id=m.sender_id WHERE m.id=?`).get(id);
  io.to(`conversation:${conversationId}`).emit('message:new', message);
  const recipients = db.prepare('SELECT user_id FROM conversation_members WHERE conversation_id=?').all(conversationId);
  for (const recipient of recipients) io.to(`user:${recipient.user_id}`).emit('inbox:changed');
  res.status(201).json({ message });
});

function validateContactSelection(creatorId, memberIds) {
  const uniqueIds = [...new Set(memberIds.map(String))].filter(id => id !== creatorId);
  if (uniqueIds.length < 1 || uniqueIds.length > 25) return { error: 'Выбери от 1 до 25 собеседников.' };
  for (const id of uniqueIds) {
    if (!db.prepare('SELECT 1 FROM users WHERE id=?').get(id)) return { error: 'Один из пользователей больше не существует.' };
    if (!hasDirectHistory(creatorId, id)) return { error: 'В группу можно приглашать только людей, с которыми уже есть личная переписка.' };
  }
  return { ids: uniqueIds };
}

app.post('/api/groups', auth, (req, res) => {
  const name = String(req.body.name || '').trim();
  const memberIds = Array.isArray(req.body.member_ids) ? req.body.member_ids : [];
  if (name.length < 2 || name.length > 50) return res.status(400).json({ error: 'Название группы: от 2 до 50 символов.' });
  const validation = validateContactSelection(req.user.id, memberIds);
  if (validation.error) return res.status(400).json({ error: validation.error });
  const id = crypto.randomUUID();
  const create = db.transaction(() => {
    db.prepare("INSERT INTO conversations (id,type,name,created_by) VALUES (?,'group',?,?)").run(id, name, req.user.id);
    const add = db.prepare('INSERT INTO conversation_members (conversation_id,user_id,role) VALUES (?,?,?)');
    add.run(id, req.user.id, 'owner');
    for (const memberId of validation.ids) add.run(id, memberId, 'member');
  });
  create();
  for (const userId of [req.user.id, ...validation.ids]) io.to(`user:${userId}`).emit('inbox:changed');
  res.status(201).json({ conversation_id: id });
});

app.post('/api/groups/:id/invite', auth, (req, res) => {
  const conversationId = req.params.id;
  const targetId = String(req.body.user_id || '');
  const group = db.prepare("SELECT * FROM conversations WHERE id=? AND type='group'").get(conversationId);
  if (!group || !requireMember(conversationId, req.user.id)) return res.status(404).json({ error: 'Группа не найдена.' });
  if (!targetId || targetId === req.user.id) return res.status(400).json({ error: 'Выбери другого пользователя.' });
  if (!db.prepare('SELECT 1 FROM users WHERE id=?').get(targetId)) return res.status(404).json({ error: 'Аккаунт не найден.' });
  if (requireMember(conversationId, targetId)) return res.status(409).json({ error: 'Этот человек уже в группе.' });
  if (!hasDirectHistory(req.user.id, targetId)) return res.status(403).json({ error: 'Приглашать можно только собеседников, с которыми уже есть личная переписка.' });
  try {
    db.prepare("INSERT INTO conversation_members (conversation_id,user_id,role) VALUES (?,?,'member')").run(conversationId, targetId);
  } catch { return res.status(409).json({ error: 'Не получилось добавить участника.' }); }
  io.to(`user:${targetId}`).emit('inbox:changed');
  io.to(`user:${req.user.id}`).emit('inbox:changed');
  res.json({ ok: true });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'AlienStageTelegram' }));
app.get('/', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));

// Realtime sockets use the same signed, HttpOnly login cookie as the REST API.
io.use((socket, next) => {
  try {
    const token = cookie.parse(socket.handshake.headers.cookie || '').ast_session;
    const payload = jwt.verify(token || '', JWT_SECRET);
    const user = db.prepare('SELECT id FROM users WHERE id=?').get(payload.sub);
    if (!user) return next(new Error('Нужно войти в аккаунт.'));
    socket.userId = user.id;
    next();
  } catch { next(new Error('Нужно войти в аккаунт.')); }
});
const onlineCounts = new Map();
io.on('connection', socket => {
  const userId = socket.userId;
  socket.join(`user:${userId}`);
  const ids = db.prepare('SELECT conversation_id FROM conversation_members WHERE user_id=?').all(userId);
  for (const row of ids) socket.join(`conversation:${row.conversation_id}`);
  socket.on('conversation:subscribe', conversationId => {
    if (typeof conversationId === 'string' && conversationId.length <= 80 && requireMember(conversationId, userId)) {
      socket.join(`conversation:${conversationId}`);
    }
  });
  onlineCounts.set(userId, (onlineCounts.get(userId) || 0) + 1);
  socket.emit('presence:snapshot', [...onlineCounts.keys()]);
  io.emit('presence:update', { user_id: userId, online: true });
  socket.on('disconnect', () => {
    const count = (onlineCounts.get(userId) || 1) - 1;
    if (count <= 0) {
      onlineCounts.delete(userId);
      io.emit('presence:update', { user_id: userId, online: false });
    } else onlineCounts.set(userId, count);
  });
});

app.use('/api', (_req, res) => res.status(404).json({ error: 'Такого адреса API нет.' }));
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'Аватар должен быть меньше 3 МБ.' : 'Не удалось загрузить изображение.' });
  console.error(err);
  res.status(500).json({ error: 'Внутренняя ошибка сервера. Попробуй ещё раз.' });
});

function startServer(port = Number(process.env.PORT || 3000), host = '0.0.0.0') {
  return new Promise((resolve, reject) => {
    const onError = error => reject(error);
    server.once('error', onError);
    server.listen(port, host, () => {
      server.removeListener('error', onError);
      const address = server.address();
      const actualPort = address && typeof address === 'object' ? address.port : port;
      console.log(`AlienStageTelegram запущен: http://127.0.0.1:${actualPort}`);
      if (!process.env.JWT_SECRET) console.warn('Для публикации задай JWT_SECRET в .env');
      resolve({ server, app, io, port: actualPort, url: `http://127.0.0.1:${actualPort}` });
    });
  });
}

if (require.main === module) {
  startServer();
}

module.exports = { app, server, io, startServer };
