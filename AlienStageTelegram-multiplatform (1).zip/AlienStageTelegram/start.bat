@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo       AlienStageTelegram - START
echo ==========================================

where node >nul 2>nul
if errorlevel 1 goto no_node
where npm >nul 2>nul
if errorlevel 1 goto no_npm

if not exist "node_modules" (
    echo Installing required packages...
    call npm install
    if errorlevel 1 goto install_failed
)

echo Starting AlienStageTelegram at http://localhost:3000
echo Keep this window open while using the website.
call npm start
echo.
echo The server has stopped.
pause
exit /b 0

:no_node
echo Node.js was not found.
echo Install Node.js 22 or newer from https://nodejs.org/en/download/
echo During installation, keep the option to add Node.js to PATH enabled.
echo Then close and reopen this window and run start.bat again.
pause
exit /b 1

:no_npm
echo npm was not found. Repair or reinstall Node.js 22 or newer.
echo Download: https://nodejs.org/en/download/
echo Then close and reopen this window and run start.bat again.
pause
exit /b 1

:install_failed
echo Package installation failed. Check your internet connection and try again.
pause
exit /b 1
